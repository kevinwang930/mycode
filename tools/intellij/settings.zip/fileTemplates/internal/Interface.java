#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
  *@ClassName ${NAME}
  *@Description TODO
  *@Date ${DATE}
  *@version 1.0   
  **/
public interface ${NAME} {
}
